import json
import copy
# from data.enchantments import properties_list
from tkinter import *


# list of properties
properties_list = ["Mind", "Body", "Soul", "Create", "Destroy", "Negate", "Transform", "Transfer", "Air", "Earth",
                   "Fire", "Water", "Death", "Life", "Chaos", "Order", "Time", "Energy", "Knowledge"]


# global variable
selected_enchantment = ""
selected_equipment = ""
combinations_all_p = []


def sort_second(y):
    return y[1]


def combo_recursion(combo_items, combo_value, items, index, target_value, solution):
    if len(combo_items) > 5:
        return
    if combo_value >= target_value:
        solution.append(combo_items)

    while index < len(items):
        ci = combo_items.copy()
        ci.append(items[index][0])
        cv = combo_value + items[index][1]
        combo_recursion(ci, cv, items, index, target_value, solution)
        index = index + 1


def subtract_substrings(unsorted_list):
    unsorted_list.sort(key=len)
    for sub_list in unsorted_list:
        for greater_list in unsorted_list:
            greater_list_copy = greater_list.copy()
            no_sub_list = False
            if len(sub_list) < len(greater_list):
                for sub_item in sub_list:
                    if sub_item not in greater_list_copy:
                        no_sub_list = True
                        break
                    else:
                        greater_list_copy.remove(sub_item)
            else:
                no_sub_list = True
            if not no_sub_list:
                unsorted_list.remove(greater_list)

    return unsorted_list


def add_item():
    with open("data/items.json") as j:
        items = json.load(j)
        item_name = input("Write the name of the item ")
        if item_name in items.keys():
            # print(f"{item_name} already exists:")
            print(items.get(item_name))
            change = input("do you want to change it? (y/n)")
            if change == "y":
                items.pop(item_name)
            else:
                return
        while True:
            prop1 = input("name of the first property: ")
            prop1 = prop1.capitalize()
            if prop1 in properties_list:
                break
            else:
                print("Invalid property name")
        value1 = int(input("value of the first property: "))
        while True:
            prop2 = input("name of the second property: ")
            prop2 = prop2.capitalize()
            if prop2 in properties_list:
                break
            else:
                print("Invalid property name")
        value2 = int(input("value of the second property: "))
        while True:
            prop3 = input("name of the third property: ")
            prop3 = prop3.capitalize()
            if prop3 in properties_list:
                break
            else:
                print("Invalid property name")
        value3 = int(input("value of the third property: "))

        value_dict = dict({})
        value_dict.update({prop1: value1})
        value_dict.update({prop2: value2})
        value_dict.update({prop3: value3})
        items.update({item_name: value_dict})

    with open("data/items.json", "w") as update_json:
        json.dump(items, update_json, sort_keys=True)


def add_enchanting():
    with open("data/enchantments.json") as k:
        enchantments = json.load(k)
        enchanting_name = input("Name of enchanting: ")
        if enchanting_name in enchantments.keys():
            # print(f"{enchanting_name} is already in the list")
            return
        while True:
            prop1 = input("first prop")
            prop1 = prop1.capitalize()
            if prop1 in properties_list:
                break
            else:
                print("Invalid prop")
        while True:
            prop2 = input("second prop")
            prop2 = prop2.capitalize()
            if prop2 in properties_list:
                break
            else:
                print("Invalid prop")
        while True:
            prop3 = input("third prop")
            prop3 = prop3.capitalize()
            if prop3 in properties_list:
                break
            else:
                print("Invalid prop")
        while True:
            prop4 = input("fourth prop")
            prop4 = prop4.capitalize()
            if prop4 in properties_list:
                break
            else:
                print("Invalid prop")

        four_props = [prop1, prop2, prop3, prop4]
        enchantments.update({enchanting_name: four_props})

    with open("data/enchantments.json", "w") as update_json:
        json.dump(enchantments, update_json, sort_keys=True)


def find_combos(list_a, list_b):
    list_c = []
    found_comb = []
    for combo_a in list_a:
        for combo_b in list_b:
            found_comb.extend(copy.deepcopy(combo_a))
            for item_b in combo_b:
                if item_b in found_comb:
                    found_comb.remove(item_b)
            found_comb.extend(copy.deepcopy(combo_b))
            if len(found_comb) <= 5:
                list_c.append(copy.deepcopy(found_comb))
            found_comb.clear()
    return list_c


def get_props(combo, minimum):
    # get props of an item combo
    prop_values = dict({})
    for prop in properties_list:
        prop_values[prop] = 0

    # get the value of all properties
    for item in combo:
        props_of_one_item = items_dict.get(item)
        for prop, value in props_of_one_item.items():
            temp_value = prop_values[prop]
            temp_value = temp_value + value
            prop_values.update({prop: temp_value})

    # delete props with low values
    props_to_be_deleted = []
    for prop, value in prop_values.items():
        if value < minimum:
            props_to_be_deleted.append(prop)
    for prop in props_to_be_deleted:
        prop_values.pop(prop)
    return prop_values


def get_enchantments(props_dict):
    # find enchantments with this props
    list_enchantments = []
    for enchantment, prop_list in enchantments_dict.items():
        is_enchantment = True
        for prop in prop_list:
            if prop not in props_dict.keys():
                is_enchantment = False
                break
        if is_enchantment and enchantment in equipments_dict[selected_equipment]:
            list_enchantments.append(enchantment)
    return list_enchantments


def test_current_combos(enchantment, combo_list, minimum):
    # double check if the combos are allowed
    for c in combo_list:
        allowed_enchantments = get_enchantments(get_props(c, minimum))
        if enchantment not in allowed_enchantments:
            print(c)
            raise Exception("Invalid combination")


def find_other_enchantments(combo):
    # get all other enchantments that are possible too
    other_enchantments = get_enchantments(get_props(combo, 2))
    other_enchantments.remove(selected_enchantment)
    return other_enchantments


def start_search_combinations(enchantment_name, current_equip):
    global selected_enchantment
    global selected_equipment
    global combination_buttons
    destroy_combinations()
    selected_enchantment = enchantment_name
    selected_equipment = current_equip

    create_list_of_all_combinations()


def create_list_of_all_combinations():
    global selected_enchantment
    global combinations_all_p
    global selected_tier
    try:
        enchantments_dict.get(selected_enchantment)[0]
    except TypeError:
        print("No enchantment selected")
        return
    # print(f"selected enchantment: {selected_enchantment}")
    # get properties, create list of items with that properties
    p1 = enchantments_dict.get(selected_enchantment)[0]
    p2 = enchantments_dict.get(selected_enchantment)[1]
    p3 = enchantments_dict.get(selected_enchantment)[2]
    p4 = enchantments_dict.get(selected_enchantment)[3]
    items_with_p1 = []
    items_with_p2 = []
    items_with_p3 = []
    items_with_p4 = []
    for item, props in items_dict.items():
        for prop, value in props.items():
            if p1 == prop:
                items_with_p1.append((item, value))
            if p2 == prop:
                items_with_p2.append((item, value))
            if p3 == prop:
                items_with_p3.append((item, value))
            if p4 == prop:
                items_with_p4.append((item, value))

    # sort the item lists
    items_with_p1.sort(key=sort_second, reverse=True)
    items_with_p2.sort(key=sort_second, reverse=True)
    items_with_p3.sort(key=sort_second, reverse=True)
    items_with_p4.sort(key=sort_second, reverse=True)

    # create item combinations for each prop
    combinations_p1 = []
    combinations_p2 = []
    combinations_p3 = []
    combinations_p4 = []

    # selected tier
    if selected_tier.get() == 1:
        minimum_value = 2
    elif selected_tier.get() == 2:
        minimum_value = 5
    elif selected_tier.get() == 3:
        minimum_value = 10
    else:
        raise Exception("Invalid tier")

    for num, item in enumerate(items_with_p1):
        cl = [item[0]]
        combo_recursion(cl, item[1], items_with_p1, num, minimum_value, combinations_p1)
    for num, item in enumerate(items_with_p2):
        cl = [item[0]]
        combo_recursion(cl, item[1], items_with_p2, num, minimum_value, combinations_p2)
    for num, item in enumerate(items_with_p3):
        cl = [item[0]]
        combo_recursion(cl, item[1], items_with_p3, num, minimum_value, combinations_p3)
    for num, item in enumerate(items_with_p4):
        cl = [item[0]]
        combo_recursion(cl, item[1], items_with_p4, num, minimum_value, combinations_p4)
    # combine all combinations
    combinations_p1 = subtract_substrings(combinations_p1)
    combinations_p2 = subtract_substrings(combinations_p2)
    combinations_p3 = subtract_substrings(combinations_p3)
    combinations_p4 = subtract_substrings(combinations_p4)

    combinations_all_p.clear()
    combinations_all_p = find_combos(combinations_p1, combinations_p2)
    combinations_all_p = find_combos(combinations_all_p, combinations_p3)
    combinations_all_p = find_combos(combinations_all_p, combinations_p4)

    combinations_all_p = subtract_substrings(combinations_all_p)
    # double check
    test_current_combos(selected_enchantment, combinations_all_p, minimum_value)
    show_combination("init")


# present all combinations of selected enchantment
def show_combination(keyword):
    # Combo list
    global combination_buttons
    global next_page_button
    global previous_page_button
    global combination_counter
    if keyword == "init":
        combination_counter = 0
    elif keyword == "counter_higher":
        combination_counter = combination_counter + 10
    elif keyword == "counter_lower":
        if combination_counter > 10:
            combination_counter = combination_counter - 10
        else:
            combination_counter = 0
    elif keyword == "tier":
        # print(f"yes {combinations_all_p}")
        combination_counter = 0
    destroy_combinations()

    row_c = 16
    column_c = 0
    if len(combinations_all_p) == 0:
        Label(window, text="No Combination possible!", font=("None", 14)).grid(row=row_c, column=column_c, columnspan=3,
                                                                               sticky="ew")
    for x in range(10):
        if combination_counter + x >= len(combinations_all_p):
            break
        beautiful_text = str(combinations_all_p[combination_counter + x])
        beautiful_text = beautiful_text[1:-1]
        beautiful_text = beautiful_text.replace("'", "")
        button = Button(window, text=beautiful_text,
                        command=lambda z=combinations_all_p[combination_counter + x]: show_props(z))
        combination_buttons.append(button)
        combination_buttons[-1].grid(row=row_c, column=column_c, columnspan=3, sticky="ew")
        row_c = row_c + 1
    if combination_counter > 0:
        # make previous button visible
        previous_page_button.grid()
    else:
        previous_page_button.grid_remove()
    if combination_counter + 10 < len(combinations_all_p):
        # make next button visible
        next_page_button.grid()
    else:
        next_page_button.grid_remove()


# present props with value of selected combo
def show_props(combo):
    global prop_title
    global props_list

    destroy_props_wrong_enchants()
    # store props
    prop_title.grid()
    props = get_props(combo, 1)
    row = 16
    column = 3
    for prop, value in props.items():
        prop_text = "  " + prop + ": "
        value_text = str(value)
        props_list.append(Label(window, text=prop_text))
        props_list[-1].grid(row=row, column=column, sticky="w")
        props_list.append(Label(window, text=value_text))
        props_list[-1].grid(row=row, column=column + 1, sticky="w")
        row = row + 1
    show_wrong_enchantments(props)


# present other enchants possible with that combo
def show_wrong_enchantments(props):
    global wrong_enchant_title
    global wrong_enchant_list
    wrong_enchant_title.grid()
    enchants = get_enchantments(props)
     # print(F"enchants: {enchants}")
    row = 16
    column = 5
    for enchant in enchants:
        wrong_enchant_list.append(Label(window, text=enchant))
        wrong_enchant_list[-1].grid(row=row, column=column, sticky="we")
        row = row+1


def destroy_combinations():
    global combination_buttons

    prop_title.grid_remove()
    wrong_enchant_title.grid_remove()
    for button in combination_buttons:
        button.destroy()
    combination_buttons.clear()

    destroy_props_wrong_enchants()


def destroy_props_wrong_enchants():
    global prop_title
    global props_list
    global wrong_enchant_title
    global wrong_enchant_list

    for enchant in wrong_enchant_list:
        enchant.destroy()
    wrong_enchant_list.clear()
    for prop in props_list:
        prop.destroy()
    props_list.clear()


# main
with open("data/items.json") as f:
    with open("data/enchantments.json") as ff:
        with open("data/equipment.json") as fff:
            equipments_dict = json.load(fff)
            enchantments_dict = json.load(ff)
            items_dict = json.load(f)
            # window creation
            window = Tk()
            window.title("Enchantment Generator")
            window.minsize(600, 400)
            column_counter = 0
            row_counter = 0

            # Enchantment list
            enchantment_buttons = list()
            combination_buttons = list()
            for equip in equipments_dict.keys():
                temp_row = row_counter
                if len(equipments_dict[equip]) > 14:
                    Label(window, text=equip, font=("none", 16)) \
                        .grid(row=row_counter, column=column_counter, sticky="ew", columnspan=2)
                else:
                    Label(window, text=equip, font=("none", 16)) \
                        .grid(row=row_counter, column=column_counter, sticky="ew")
                row_counter = row_counter + 1
                pad = True
                for en in equipments_dict[equip]:
                    enchantment_buttons.append(Button(window, text=en,
                                                      command=lambda x=en, y=equip: start_search_combinations(x, y)))
                    if pad:
                        enchantment_buttons[-1].grid(row=row_counter, column=column_counter, sticky="ew", padx=[15, 0])
                    else:
                        enchantment_buttons[-1].grid(row=row_counter, column=column_counter, sticky="ew")
                    # separate in two columns when too many enchantments
                    if len(equipments_dict[equip]) > 14 and row_counter >= len(equipments_dict[equip]) / 2:
                        row_counter = temp_row
                        column_counter = column_counter + 1
                        pad = False
                    row_counter = row_counter + 1
                row_counter = temp_row
                column_counter = column_counter + 1
            # Tier list
            selected_tier = IntVar()
            selected_tier.set(1)
            Label(window, text="Selected Tier:", font=("none", 14)).grid(column=column_counter, row=row_counter)
            Radiobutton(window, text="Tier 1", variable=selected_tier, value=1,
                        command=lambda: create_list_of_all_combinations()) \
                .grid(column=column_counter, row=row_counter + 1)
            Radiobutton(window, text="Tier 2", variable=selected_tier, value=2,
                        command=lambda: create_list_of_all_combinations()) \
                .grid(column=column_counter, row=row_counter + 2)
            Radiobutton(window, text="Tier 3", variable=selected_tier, value=3,
                        command=lambda: create_list_of_all_combinations()) \
                .grid(column=column_counter, row=row_counter + 3)

            # Combination
            Label(window, text="Combinations", font=("None", 16)) \
                .grid(column=0, columnspan=3, row=15)

            # next/previous page marker
            combination_counter = 0
            previous_page_img = PhotoImage(file="data/previous_page.png")
            previous_page_button = Button(window, image=previous_page_img,
                                          command=lambda: show_combination("counter_lower"))
            previous_page_button.grid(row=26, column=0, sticky="w")
            previous_page_button.image = previous_page_img
            next_page_img = PhotoImage(file="data/next_page.png")
            next_page_button = Button(window, image=next_page_img, command=lambda: show_combination("counter_higher"))
            next_page_button.grid(row=26, column=2, sticky="e")
            next_page_button.image = next_page_img
            previous_page_button.grid_remove()
            next_page_button.grid_remove()
            # Props list
            prop_title = Label(window, text="Properties", font=("None", 16))
            prop_title.grid(row=15, column=3, columnspan=2)
            prop_title.grid_remove()
            props_list = list()
            # Wrong Combo list
            wrong_enchant_title = Label(window, text="Wrong Enchantments", font=("None", 16))
            wrong_enchant_title.grid(row=15, column=5)
            wrong_enchant_title.grid_remove()
            wrong_enchant_list = list()

            window.mainloop()

            # while True:
            #    update_items = input("Do you want to add a new item? (y/n) ")
            #    if update_items == "y":
            #       add_item()
            #    else:
            #        break
            # while True:
            #    update_enchantments = input("Do you want to add a new enchanting? (y/n)")
            #    if update_enchantments == "y":
            #        add_enchanting()
            #    else:
            #        break
