# list of items
items_dict = dict({
    "Arnica": {"Transform": 1, "Order": 2, "Water": 4},
    "Amanita Mushrooms": {"Transform": 3, "Soul": 2, "Death": 4},
    "Antlers": {"Soul": 3, "Knowledge": 3, "Time": 2},
    "Spider Eye": {"Transfer": 3, "Mind": 2, "Knowledge": 1},
    "Zombie Brain": {"Transform": 1, "Mind": 3, "Chaos": 4},
    "Fox Tail": {"Transfer": 2, "Mind": 3, "Air": 3},
    "Crystallized Magic": {"Mind": 1, "Water": 4, "Energy": 4},
    "Mandrake Root": {"Mind": 2, "Energy": 3, "Knowledge": 2},
    "Living Wood": {"Mind": 1, "Life": 4, "Order": 2},
    "Beast Blood": {"Transfer": 4, "Energy": 2, "Fire": 2},
    "Animal Bones": {"Transfer": 2, "Soul": 2, "Earth": 2},
    "Necrotic Bone": {"Transfer": 2, "Death": 4, "Life": 3},
    "Ghoul Saliva": {"Transfer": 2, "Chaos": 3, "Death": 3},
    "Ashes": {"Transfer": 2, "Soul": 2, "Time": 3},
    "Lavender": {"Negate": 4, "Water": 1, "Energy": 2},
    "Garlic": {"Body": 2, "Earth": 2, "Energy": 2},
    "Rabbit Paw": {"Soul": 2, "Chaos": 3, "Energy": 3},
    "Dandelion": {"Air": 2, "Chaos": 1,"Time": 2},
    "Nightshade Berries": {"Body": 1, "Death": 3, "Time": 3},
    "Milkweed": {"Negate": 2, "Water": 3, "Time": 3},
    "Primordial Dust": {"Transform": 2, "Chaos": 3, "Time": 3}
    })

