# list of properties

properties_list = ["Mind", "Body", "Soul", "Create", "Destroy", "Negate", "Transform", "Transfer", "Air", "Earth",
                   "Fire", "Water", "Death", "Life", "Chaos", "Order", "Time", "Energy", "Knowledge"]

